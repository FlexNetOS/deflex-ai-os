
# eBPF Policy Placeholder

Node-level datapath and guardrails live here (XDP/L4 filters, audit, rate-limits).
Integrate with Cilium/bcc/aya as needed. Kept out of hot loop for latency.
